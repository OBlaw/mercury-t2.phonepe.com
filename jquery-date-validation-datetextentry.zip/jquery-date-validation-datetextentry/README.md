Visit http://grantm.github.com/jquery-datetextentry/ to view this documentation
in your browser.
